The Beauty RS clickable prototype

How to put this online:
1. Go to https://app.netlify.com/drop
2. Drag the whole folder called the_beauty_rs_clickable_prototype_site onto the page
3. Netlify will create a real public link you can open in Chrome and share

Main file:
index.html
